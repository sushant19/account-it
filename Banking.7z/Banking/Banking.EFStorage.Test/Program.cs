﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Banking.EFData;

namespace Banking.EFStorage.Test
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
