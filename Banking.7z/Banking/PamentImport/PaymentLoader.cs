﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Banking.Domain;

namespace PaymentImport
{
    public class PaymentLoader
    {
        public List<Operation> Load(string uri)
        {
            List<string[]> lines = File.ReadAllLines("operations.txt")
                .Select(line => line.Split('\t')
                    .Select(part => part.Trim())
                    .Where(part => part != String.Empty)
                    .ToArray())
                .ToList();

            List<Operation> payments = new List<Operation>();

            for (int i = 0; i < lines.Count; i++)
            {
                string[] line = lines[i];
                if (i % 2 == 0)
                {
                    payments.Add(new Operation());
                    payments.Last().Date = ParseDate(line[0]);
                    payments.Last().Mark = line[1];
                }
                else
                {
                    payments.Last().Amount = Decimal.Parse(line[4]);
                }
            }

            return payments;
        }

        private DateTime ParseDate(string str)
        {
            DateTime result = new DateTime(2000, 1, 1);
            int[] parts = str.Split('/').Select(st => Int32.Parse(st)).ToArray();
            return new DateTime(2000, 1, 1)
                .AddYears(parts[2])
                .AddMonths(parts[1])
                .AddDays(parts[0]);
        }
    }
}
