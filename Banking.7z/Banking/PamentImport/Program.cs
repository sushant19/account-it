﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Banking.Domain;

namespace PaymentImport
{
    class Program
    {
        static void Main(string[] args)
        {
            PaymentLoader loader = new PaymentLoader();
            var payments = loader.Load("operations.txt");
            foreach (var payment in payments)
                Console.WriteLine(payment.ToString());
            Console.ReadLine();
        }

        
    }
}
