﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Banking.Domain;
using Banking.EFData;

namespace TestData
{
    class Program
    {
        static void Main(string[] args)
        {
           

        }
    }
}
